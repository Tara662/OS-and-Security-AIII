
package frequency.analysis;
import java.util.Scanner;
public class FrequencyAnalysis {
public static String Plain_Alphabet[] = {"A", "B", "C", "D", "E", "F" ,"G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q","R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
public static String Cipher_Alphabet[]=new String[Plain_Alphabet.length];
public static void Encryption(){
	String plainText, cipherText = "";int index = 0;
	System.out.println("Enter PlainText");
	Scanner in = new Scanner(System.in);
	plainText = in.nextLine();
for(int i=0; i<plainText.length(); i++)
	{
	char c = plainText.charAt(i);
        String value = String.valueOf(c);
if(value.equals(" "))
{
cipherText = cipherText + " ";
}
else
{
for(int j=0; j<Plain_Alphabet.length; j++)
{
if(value.equalsIgnoreCase(Plain_Alphabet[j]))
{
index = j;
break;
}
}        
	cipherText = cipherText + Cipher_Alphabet[index];
        }}
 System.out.println("Cipher text of  "+plainText+"   is   "+ cipherText);
 System.out.println();
}
public static void Decryption(){
	String plainText="", cipherText = "";int index = 0;
 System.out.println("Enter CipherText");
 Scanner in = new Scanner(System.in);
 cipherText = in.nextLine();
for(int i=0; i<cipherText.length(); i++)
 {
 	char c = cipherText.charAt(i);
 String value = String.valueOf(c);
 if(value.equals(" "))
 {
 plainText = plainText + " ";
 }
 else
 {
 for(int j=0; j<Plain_Alphabet.length; j++)
 {
 if(value.equalsIgnoreCase(Cipher_Alphabet[j]))
 {
 index = j;
 break;
 }
 }
 plainText = plainText + Plain_Alphabet[index];
}
 }
 System.out.println("Plain text of  "+cipherText+"   is   "+ plainText);
 System.out.println();
}
    public static void main(String[] args) {
        String all="";
        System.out.println("Frequency Analysis Application");
     System.out.println("Please enter Alphabets to create Cipher_Alphabets table");
     	Scanner in = new Scanner(System.in);
for(int i=0;i<Cipher_Alphabet.length;i++){
String letter=in.nextLine();
    Cipher_Alphabet[i]=letter.toUpperCase();
all=all+" "+Cipher_Alphabet[i]+",";
}
System.out.println("Cipher_Alphabet = {"+all+"}");
Encryption();
Decryption();
    }
    
}
