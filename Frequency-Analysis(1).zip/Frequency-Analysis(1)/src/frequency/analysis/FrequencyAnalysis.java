
package frequency.analysis;
import java.util.Scanner;
public class FrequencyAnalysis {
public static String Plain_Alphabet[] = {"A", "B", "C", "D", "E", "F" ,"G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q","R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
public static String Cipher_Alphabet[]=new String[Plain_Alphabet.length];
    public static void main(String[] args) {
        String all="";
        System.out.println("Frequency Analysis Application");
     System.out.println("Please enter Alphabets to create Cipher_Alphabets table");
     	Scanner in = new Scanner(System.in);
for(int i=0;i<Cipher_Alphabet.length;i++){
String letter=in.nextLine();
    Cipher_Alphabet[i]=letter.toUpperCase();
all=all+" "+Cipher_Alphabet[i]+",";
}
System.out.println("Cipher_Alphabet = {"+all+"}");
Encryption();
Decryption();
    }
    
}
